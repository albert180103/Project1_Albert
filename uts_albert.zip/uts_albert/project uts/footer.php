<!-- footer -->
<footer style="background-color: lightgrey;" class="fixed-bottom">
      <p>Created with <i class="bi bi-heart-fill text-danger"></i> by <a class="text-black fw-bold" href="https://api.whatsapp.com/send?phone=6281265775569&text=udah liat semuanya, kerenn 😚">Albert Verdinan</a></p>
    </footer>
    
</body>
</html>