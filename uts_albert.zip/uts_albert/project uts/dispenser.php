<?php
    include_once 'atas.php';
    include_once 'sidebar.php';
?>
<div class="content-wrapper">

<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Praktikum 5</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Layout</a></li>
              <li class="breadcrumb-item active">Fixed Layout</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Class Dispenser</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">

<?php
require_once 'class_dispenser.php';

$awal = new Dispenser('dimas',1,1);
echo 'Volume awal galon: '.$awal->isi_awal();
echo '<br/>Volume pergelas: '.$awal->volume_gelas();
echo '<br/>Harga pergelas: '.$awal->harga_gelas();

$pembeli1 = new Dispenser('gilang',2,1);
echo '<br/><br/>'.$pembeli1->nama.' membeli'.$pembeli1->jumlahBeli.' '.$pembeli1->nama_Minuman();
echo '<br/>Total pembayaran: '.$pembeli1->format_uang($pembeli1->Bayar());
echo '<br/>Sisa volume galon '.$pembeli1->nama_Minuman().' sekarang adalah '.$pembeli1->berkurang().' ml';
echo '<br/>Total penghasilan galon: '.$pembeli1->format_uang($pembeli1->penghasilan());

$pembeli2 = new Dispenser('lala',1,2);
echo '<br/><br/>'.$pembeli2->nama.' membeli'.$pembeli2->jumlahBeli.' '.$pembeli2->nama_Minuman();
echo '<br/>Total pembayaran: '.$pembeli2->format_uang($pembeli2->Bayar());
echo '<br/>Sisa volume galon '.$pembeli2->nama_Minuman().' sekarang adalah '.$pembeli2->berkurang().' ml';
echo '<br/>Total penghasilan galon: '.$pembeli2->format_uang($pembeli2->penghasilan());

$pembeli3 = new Dispenser('lula',3,1);
echo '<br/><br/>'.$pembeli3->nama.' membeli'.$pembeli3->jumlahBeli.' '.$pembeli3->nama_Minuman();
echo '<br/>Total pembayaran: '.$pembeli3->format_uang($pembeli3->Bayar());
echo '<br/>Sisa volume galon '.$pembeli3->nama_Minuman().' sekarang adalah '.$pembeli3->berkurang().' ml';
echo '<br/>Total penghasilan galon: '.$pembeli3->format_uang($pembeli3->penghasilan());


?>

</div>

<?php
    include_once 'bawah.php'
?>